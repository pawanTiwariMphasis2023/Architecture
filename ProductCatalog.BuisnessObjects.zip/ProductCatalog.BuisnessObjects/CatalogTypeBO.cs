﻿using ProductCatalog.Domain;
using ProductCatalog.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.BuisnessObjects
{
    public class CatalogTypeBO : ICatalogTypeBO
    {
        ICatalogTypeRepository _repository;

        public CatalogTypeBO(ICatalogTypeRepository repository)
        {
            _repository = repository;
        }

        public Task<CatalogBrand> AddAsync(CatalogType brand)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<CatalogType>> GetCatalogTypeAsync()
        {
            return await _repository.GetItemsAsync();
        }

        public Task<CatalogType> GetCatalogTypeDetailsAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task UpdateAsync(CatalogType brand)
        {
            throw new NotImplementedException();
        }
    }
}
