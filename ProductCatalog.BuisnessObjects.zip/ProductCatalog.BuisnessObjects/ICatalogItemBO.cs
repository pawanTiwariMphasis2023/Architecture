﻿using ProductCatalog.Domain;
using ProductCatalog.Repository;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProductCatalog.BuisnessObjects
{
    public interface ICatalogItemBO
    {
        Task<IEnumerable<CatalogItem>> GetCatalogItemsAsync();
        Task<CatalogItem> GetDetailsAsync(int id);
        Task<CatalogItem> AddAsync(CatalogItem item);
        Task UpdateAsync(CatalogItem item);
        Task DeleteAsync(int id);
    }


}
