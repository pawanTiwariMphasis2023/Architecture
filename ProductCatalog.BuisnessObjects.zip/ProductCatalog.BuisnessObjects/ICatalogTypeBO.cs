﻿using ProductCatalog.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.BuisnessObjects
{
   public interface ICatalogTypeBO
    {
        Task<IEnumerable<CatalogType>> GetCatalogTypeAsync();
        Task<CatalogType> GetCatalogTypeDetailsAsync(int id);
        Task<CatalogBrand> AddAsync(CatalogType brand);
        Task UpdateAsync(CatalogType brand);
        Task DeleteAsync(int id);
    }
}
