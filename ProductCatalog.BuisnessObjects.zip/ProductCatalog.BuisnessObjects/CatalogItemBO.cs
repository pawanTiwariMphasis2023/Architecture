﻿using ProductCatalog.Domain;
using ProductCatalog.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.BuisnessObjects
{
    public class CatalogItemBO : ICatalogItemBO
    {
        ICatalogItemRepository _repository;

        public CatalogItemBO(ICatalogItemRepository repository)
        {
            _repository = repository;
        }
        public async Task<CatalogItem> AddAsync(CatalogItem item)
        {
            // Object level/row level validations etc ........
            // sending notifications etc...
           return await _repository.AddAsync(item);
        }

        public async Task DeleteAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }

        public async Task<CatalogItem> GetDetailsAsync(int id)
        {
            return await _repository.GetDetailsByIdAsync(id);
        }

        public async Task<IEnumerable<CatalogItem>> GetCatalogItemsAsync()
        {
            return await _repository.GetItemsAsync();
        }

        public async Task UpdateAsync(CatalogItem item)
        {
            await _repository.UpdateAsync(item);
        }
    }
}
