﻿using ProductCatalog.Domain;
using ProductCatalog.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.BuisnessObjects
{
    public class CatalogBrandBO : ICatalogBrandBO
    {
        ICatalogBrandRepository _repository;

        public CatalogBrandBO(ICatalogBrandRepository repository)
        {
            _repository = repository;
        }
        public async Task<CatalogBrand> AddAsync(CatalogBrand brand)
        {
            // Object level/row level validations etc ........
            // sending notifications etc...
           return await _repository.AddAsync(brand);
        }

        public async Task DeleteAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }

        public async Task<CatalogBrand> GetCatalogBrandDetailsAsync(int id)
        {
            return await _repository.GetDetailsByIdAsync(id);
        }

        public async Task<IEnumerable<CatalogBrand>> GetCatalogBrandsAsync()
        {
            return await _repository.GetItemsAsync();
        }

      

      

        public async Task UpdateAsync(CatalogBrand brand)
        {
            await _repository.UpdateAsync(brand);
        }
    }
}
