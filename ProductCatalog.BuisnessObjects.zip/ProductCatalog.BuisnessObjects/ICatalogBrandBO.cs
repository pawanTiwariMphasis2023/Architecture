﻿using ProductCatalog.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.BuisnessObjects
{
   public interface ICatalogBrandBO
    {
        Task<IEnumerable<CatalogBrand>> GetCatalogBrandsAsync();
        Task<CatalogBrand> GetCatalogBrandDetailsAsync(int id);
        Task<CatalogBrand> AddAsync(CatalogBrand brand);
        Task UpdateAsync(CatalogBrand brand);
        Task DeleteAsync(int id);
    }
}
