﻿
using Microsoft.EntityFrameworkCore;
using ProductCatalog.Domain;
using ProductCatalog.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.EFRepository
{
    public class CatalogTypeRepository : GenericRepository<CatalogType>,ICatalogTypeRepository
    {
        public ProductCatalogAPIContext _context;
        public CatalogTypeRepository(ProductCatalogAPIContext context): base(context)
        {
            _context = context;
        }
       

        //public async Task<CatalogItem> AddAsync(CatalogItem item)
        //{
        //    _context.CatalogItems.Add(item);
        //    await _context.SaveChangesAsync();
        //    return item;
        //}

        //public async Task DeleteAsync(int id)
        //{
        //    var catalogItem = await _context.CatalogItems.FindAsync(id);
        //    if (catalogItem == null)
        //    {
        //        throw new ApplicationException("Item does not exist");
        //    }
        //    _context.CatalogItems.Remove(catalogItem);
        //    await _context.SaveChangesAsync();
        //}

        //public async Task<CatalogItem> GetCatalogItemDetailsAsync(int id)
        //{
        //    var catalogItem = await _context.CatalogItems.Include("CatalogBrand").Include("CatalogType").Where(item => item.Id == id).FirstOrDefaultAsync();
        //    if (catalogItem == null)
        //    {
        //        throw new ApplicationException("Item does not exist");
        //    }
        //    return catalogItem;
        //}

        //public async Task<IEnumerable<CatalogItem>> GetCatalogItemsAsync()
        //{
        //    return await _context.CatalogItems.Include("CatalogBrand").Include("CatalogType").ToListAsync();
        //}

        //public async Task UpdateAsync(CatalogItem item)
        //{
        //    _context.Entry(item).State = EntityState.Modified;
        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        throw new ApplicationException("Item already updated by another user, please retry...");
        //    }
        //}
    }
}
