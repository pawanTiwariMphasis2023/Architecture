﻿using Microsoft.EntityFrameworkCore;
using ProductCatalog.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.EFRepository
{
    public class GenericRepository<T> : IGenericRepository<T> where T: class
    {
        DbContext _context;
        DbSet<T> _dbSet;
        public GenericRepository(DbContext context)
        {
            _context = context;
            _dbSet = context.Set<T>();
        }

        public virtual async Task<T> AddAsync(T item)
        {
            _dbSet.Add(item);
            await _context.SaveChangesAsync();
           return item;
        }

        public virtual async Task DeleteAsync(int id)
        {
            T entity = await _dbSet.FindAsync(id);
            _dbSet.Remove(entity);
            await _context.SaveChangesAsync();
        }

        public virtual async Task<T> GetDetailsByIdAsync(int id)
        {
            T entity = await _dbSet.FindAsync(id);
            return entity;
        }

        public virtual async Task<IEnumerable<T>> GetItemsAsync()
        {
            return await _dbSet.ToListAsync<T>();
            
        }

        public virtual async Task UpdateAsync(T item)
        {
            _context.Entry<T>(item).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}
