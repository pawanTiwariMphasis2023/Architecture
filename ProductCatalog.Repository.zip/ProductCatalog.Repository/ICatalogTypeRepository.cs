﻿using ProductCatalog.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.Repository
{
    public interface ICatalogTypeRepository : IGenericRepository<CatalogType>
    {
       
    }
}
