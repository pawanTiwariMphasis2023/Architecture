﻿using ProductCatalog.Domain;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProductCatalog.Repository
{

   
    public interface ICatalogItemRepository : IGenericRepository<CatalogItem>
    {
        //Task<IEnumerable<CatalogItem>> GetCatalogItemsAsync();
        //Task<CatalogItem> GetCatalogItemDetailsAsync(int id);
        //Task<CatalogItem> AddAsync(CatalogItem item);
        //Task UpdateAsync(CatalogItem item);
        //Task DeleteAsync(int id);
    }

}
