﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductCatalog.Repository
{
    public interface IGenericRepository<T>
    {
        Task<IEnumerable<T>> GetItemsAsync();
        Task<T> GetDetailsByIdAsync(int id);
        Task<T> AddAsync(T item);
        Task UpdateAsync(T item);
        Task DeleteAsync(int id);
    }

}
